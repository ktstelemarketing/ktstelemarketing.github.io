// Smooth scrolling is already handled by CSS `scroll-behavior: smooth`
